export interface Cidade {
    nome:string;
    uf:string;
}