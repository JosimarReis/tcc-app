export interface Anuncio{
    _id:string; 
    titulo:string;
    url:string;
    cidade:string;
    uf:string;
    latitude:string;
    longitudo:string;
    preco:string;
    descricao:string;
    localizacao;
}