import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

import { Usuario } from '../../models/usuario';
import { Config } from './../../models/config';
/*
  Generated class for the AuthServiceProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class AuthServiceProvider {
  
  currentUser: Usuario;
  config = new Config();

  constructor(private http:Http){

  }

  public login(credentials){
    if(credentials.email===null || credentials.senha ===null){
      return Observable.throw("Adicione seu email e/ou senha")
    }else {
      return Observable.create(observer => {
        let headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
            
      
        return this.http.post(`${this.config.urlServer()}/api/anuncios/`, JSON.stringify(credentials), {headers: headers})
        .map(res => <Usuario[]>(res.json()));
    
        let access = (credentials.senha == 'pass' && credentials.email =="email");
        this.currentUser = new Usuario('Josimar User','email','pass',true,false);
        observer.next(true);
        observer.complete();
      })
    }
  }

  public getUserInfo(): Usuario{
    return this.currentUser;
  }

  public logout(){
    return Observable.create(observer =>{
      this.currentUser =null;
      observer.next(true);
      observer.complete();
    });
  }
  public register(credentials){
    return false;
  }

}
