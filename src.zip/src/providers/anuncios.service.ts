import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';

import { Anuncio } from './../models/anuncio';
import { Usuario } from './../models/usuario';
import { Config } from './../models/config';


/*
  Generated class for the AnunciosService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class AnunciosService {

  config = new Config();
  anuncios: Anuncio[];
  usuario= new Usuario('josimar','josimargeraldoreis@gmail.com','gr36',true, true);

  constructor(public http: Http) {
  }
  
  loadAnuncio(produto,cidade, uf): Observable<Anuncio[]>{

    let headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');

    let consulta ={
      termo:produto,
      cidade:cidade,
      sigla:uf,
      usuario:this.usuario
    } ;
    
  
    return this.http.post(`${this.config.urlServer()}/api/anuncios/`, JSON.stringify(consulta), {headers: headers})
    .map(res => <Anuncio[]>(res.json()));

  }
}
