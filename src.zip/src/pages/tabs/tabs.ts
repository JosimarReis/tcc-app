import { Component } from '@angular/core';

import { AboutPage } from '../about/about';
import { ContactPage } from '../contact/contact';
import { Pesquisa } from './../pesquisa/pesquisa';
import { NavController } from "ionic-angular";
import { Usuario } from "../../models/usuario";
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { LoginPage} from './../login/login';

@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {
  usuario: Usuario;
  

  tab1Root = Pesquisa;
  tab2Root = AboutPage;
  tab3Root = ContactPage;
  tab4Root = '';

   constructor(private nav: NavController, private auth:AuthServiceProvider) {
    this.usuario = this.auth.getUserInfo();
  }
 
  public logout(){
    console.log('vc quer sair');
    this.auth.logout().subscribe(succ => {
      this.nav.setRoot(LoginPage);
    });
  }
  

}
