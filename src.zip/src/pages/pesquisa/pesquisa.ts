import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, AlertController } from 'ionic-angular';

import { Cidade } from "../../models/cidade";
import { Anuncio } from "../../models/anuncio";
import { CidadesService } from './../../providers/cidades.service';
import { AnunciosService } from './../../providers/anuncios.service';
import{ Usuario } from '../../models/usuario'


@IonicPage()
@Component({
  selector: 'page-pesquisa',
  templateUrl: 'pesquisa.html',
})
export class Pesquisa {
  title: string = "Pesquisar";
  usuario:Usuario;
  loading:any;
  isLoggedIn:boolean= false;
  selectUf:string;
  selectCidade:string;
  termo:string='';


  cidades: Cidade[];
  anuncios: Anuncio[];

  username = '';
  email = '';

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private cidadesService: CidadesService,
    private anunciosService: AnunciosService,
    public loadingCtrl: LoadingController,
    public alertCtrl: AlertController
     ) {
      if(localStorage.getItem("token")) {
        this.isLoggedIn = true;       
       // this.usuario = this.auth.getUserInfo();
      }
  }

  showLoader(){
    this.loading = this.loadingCtrl.create({
        content: 'Autenticando...'
    });

  }
  //pesquisa por termo digitado e localizacao
  pesquisar(termo){
    this.anuncios= [];
    this.anunciosService.loadAnuncio(this.termo,this.selectCidade, this.selectUf).subscribe(
      anuncios =>{
        this.anuncios=anuncios;
        console.log(this.anuncios);
      }
    );
  }
  verDetalhes(termo){
    this.anuncios= [];
    this.anunciosService.loadAnuncio(termo,this.selectCidade, this.selectUf).subscribe(
      anuncios =>{
        this.anuncios=anuncios;
        console.log(this.anuncios);
      }
    );
  }



  //filtra cidades por estado e popula o selectbox com cidades para cada estado.
   carregarCidades(uf:string){
     this.cidadesService.loadCidades(uf).subscribe(cidades=>{
       this.cidades=cidades;
     })
   }
   //aviso para selecionar um estado
    selecioneUfAlert() {
    let alert = this.alertCtrl.create({
      title: 'Selecione um estado!',
      subTitle: '',
      buttons: ['OK']
    });
    alert.present();
  }

}
